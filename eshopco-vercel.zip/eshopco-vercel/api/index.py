import json
from pathlib import Path
from statistics import mean, quantiles
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['POST'], allow_headers=['*'])
DATA = json.loads((Path(__file__).resolve().parent.parent / 'telemetry.json').read_text())

class Request(BaseModel):
    regions: list[str]
    threshold_ms: float = Field(default=180)

@app.post('/api')
def metrics(request: Request):
    result = {}
    for region in request.regions:
        records = [r for r in DATA if r['region'] == region]
        if not records:
            result[region] = {'avg_latency': None, 'p95_latency': None, 'avg_uptime': None, 'breaches': 0}
            continue
        latencies = sorted(r['latency_ms'] for r in records)
        # Linear interpolation, equivalent to numpy.percentile(..., 95) default.
        position = (len(latencies) - 1) * .95
        lower = int(position)
        upper = min(lower + 1, len(latencies) - 1)
        p95 = latencies[lower] + (latencies[upper] - latencies[lower]) * (position - lower)
        result[region] = {
            'avg_latency': round(mean(latencies), 4),
            'p95_latency': round(p95, 4),
            'avg_uptime': round(mean(r['uptime_pct'] for r in records), 4),
            'breaches': sum(r['latency_ms'] > request.threshold_ms for r in records),
        }
    return result
